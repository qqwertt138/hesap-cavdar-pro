package com.cavdar.hesap;
import android.app.*;import android.content.*;import android.content.pm.ServiceInfo;import android.location.*;import android.os.*;import java.text.SimpleDateFormat;import java.util.*;
public class TrackService extends Service implements LocationListener{
Location last;long prevT;LocationManager lm;SharedPreferences p;
public IBinder onBind(Intent i){return null}
public int onStartCommand(Intent i,int f,int id){
NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
nm.createNotificationChannel(new NotificationChannel("trk","Sürüş takibi",NotificationManager.IMPORTANCE_LOW));
Notification n=new Notification.Builder(this,"trk").setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("Sürüş takibi açık").setContentText("Mesafe ve süre kaydediliyor").setContentIntent(PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE)).build();
startForeground(5,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
p=getSharedPreferences("a",0);p.edit().putBoolean("trk",true).apply();
try{lm=(LocationManager)getSystemService(LOCATION_SERVICE);lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,2000,0,this)}catch(Exception e){stopSelf()}
return START_STICKY}
public void onLocationChanged(Location l){
if(l.getAccuracy()>40)return;long t=l.getTime();double dtf=prevT>0?(t-prevT)/1000.0:0;prevT=t;
if(last==null){last=l;return}
float d=last.distanceTo(l);double g=(t-last.getTime())/1000.0;boolean mv=l.hasSpeed()?l.getSpeed()>=1.5:d>=12;
if(g>180||(d>=12&&d/Math.max(g,1)>55)){last=l;return}
String k="t_"+new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());String[] a=p.getString(k,"0|0").split("\\|");
double km=Double.parseDouble(a[0]),sec=Double.parseDouble(a[1]);
if(mv&&dtf>0&&dtf<=15)sec+=dtf;if(d>=12){km+=d/1000;last=l}
p.edit().putString(k,km+"|"+sec).apply()}
public void onProviderEnabled(String s){}public void onProviderDisabled(String s){}public void onStatusChanged(String s,int i,Bundle b){}
public void onDestroy(){try{lm.removeUpdates(this)}catch(Exception e){}getSharedPreferences("a",0).edit().putBoolean("trk",false).apply();super.onDestroy()}}
