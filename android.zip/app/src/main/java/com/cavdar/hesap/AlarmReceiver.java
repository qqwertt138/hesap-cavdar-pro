package com.cavdar.hesap;
import android.app.*;import android.content.*;import android.media.AudioAttributes;import android.net.Uri;import org.json.JSONObject;import java.util.Calendar;
public class AlarmReceiver extends BroadcastReceiver{
static final String CH="vardiya1";
@Override public void onReceive(Context c,Intent i){fire(c,i.getStringExtra("k"));schedule(c)}
static void fire(Context c,String k){
NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
if(nm.getNotificationChannel(CH)==null){NotificationChannel ch=new NotificationChannel(CH,"Vardiya alarmı",NotificationManager.IMPORTANCE_HIGH);
ch.setSound(Uri.parse("android.resource://"+c.getPackageName()+"/"+R.raw.siren),new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
ch.enableVibration(true);ch.setVibrationPattern(new long[]{0,500,200,500,200,800});nm.createNotificationChannel(ch)}
boolean s="s".equals(k);
Notification n=new Notification.Builder(c,CH).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(s?"Vardiya başladı":"Vardiya bitti").setContentText(s?"Vardiyanız başlamıştır. İyi çalışmalar.":"Vardiyanız bitmiştir. Elinize emeğinize sağlık.").setAutoCancel(true).setContentIntent(PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_IMMUTABLE)).build();
nm.notify(s?1:2,n)}
static void schedule(Context c){try{
AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);Intent in=new Intent(c,AlarmReceiver.class);
am.cancel(PendingIntent.getBroadcast(c,7,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
SharedPreferences q=c.getSharedPreferences("a",0);if(q.getBoolean("lock",false)||q.getBoolean("noshift",false))return;
String j=q.getString("cfg","");if(j.isEmpty())return;
JSONObject o=new JSONObject(j);if(!o.optBoolean("on"))return;JSONObject d=o.getJSONObject("days");
long best=Long.MAX_VALUE,now=System.currentTimeMillis();String kind="";
for(int off=0;off<8;off++){Calendar x=Calendar.getInstance();x.add(Calendar.DAY_OF_YEAR,off);
JSONObject dd=d.optJSONObject(""+(x.get(Calendar.DAY_OF_WEEK)-1));if(dd==null||!dd.optBoolean("on"))continue;
for(String t:new String[]{"s","e"}){String[] a=dd.getString(t).split(":");Calendar y=(Calendar)x.clone();
y.set(Calendar.HOUR_OF_DAY,Integer.parseInt(a[0]));y.set(Calendar.MINUTE,Integer.parseInt(a[1]));y.set(Calendar.SECOND,0);y.set(Calendar.MILLISECOND,0);
if(t.equals("e")&&dd.getString("e").compareTo(dd.getString("s"))<=0)y.add(Calendar.DAY_OF_YEAR,1);
long m=y.getTimeInMillis();if(m>now+1000&&m<best){best=m;kind=t}}}
if(best==Long.MAX_VALUE)return;in.putExtra("k",kind);
PendingIntent pi=PendingIntent.getBroadcast(c,7,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
PendingIntent sh=PendingIntent.getActivity(c,8,new Intent(c,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);
am.setAlarmClock(new AlarmManager.AlarmClockInfo(best,sh),pi)}catch(Exception e){}}}
