package com.cavdar.hesap;
import android.content.*;
public class BootReceiver extends BroadcastReceiver{@Override public void onReceive(Context c,Intent i){AlarmReceiver.schedule(c)}}
