package com.cavdar.hesap;
import android.Manifest;import android.app.Activity;import android.app.NotificationChannel;import android.app.NotificationManager;import android.content.*;import android.content.pm.PackageManager;import android.net.Uri;import android.os.*;import android.provider.MediaStore;import android.webkit.*;import android.widget.Toast;import org.json.JSONObject;import java.io.OutputStream;import java.util.Map;import java.util.HashMap;import com.google.firebase.remoteconfig.*;
public class MainActivity extends Activity{
WebView w;ValueCallback<Uri[]> fc;static final String F=Manifest.permission.ACCESS_FINE_LOCATION;
@Override protected void onCreate(Bundle b){super.onCreate(b);w=new WebView(this);w.setBackgroundColor(0xFF07122B);setContentView(w);getWindow().setStatusBarColor(0xFF0F2247);
WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);
w.addJavascriptInterface(new Br(),"Android");
w.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(fc!=null)fc.onReceiveValue(null);fc=cb;try{startActivityForResult(p.createIntent(),9)}catch(Exception e){fc=null;return false}return true}});
w.loadUrl("file:///android_asset/index.html");
if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},2);
getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("duyuru","Duyurular",NotificationManager.IMPORTANCE_HIGH));
AlarmReceiver.schedule(this);initCfg()}
boolean cok;
@Override protected void onResume(){super.onResume();if(cok)fetchCfg()}
void initCfg(){FirebaseRemoteConfig r=FirebaseRemoteConfig.getInstance();
r.setConfigSettingsAsync(new FirebaseRemoteConfigSettings.Builder().setMinimumFetchIntervalInSeconds(900).build());
HashMap<String,Object> d=new HashMap<>();d.put("app_locked",false);d.put("lock_message","");d.put("min_version",0L);d.put("update_url","");d.put("feature_tracking",true);d.put("feature_shift",true);d.put("feature_export",true);d.put("announcement","");
r.setDefaultsAsync(d).addOnCompleteListener(t->{cok=true;applyCfg();fetchCfg()})}
void fetchCfg(){FirebaseRemoteConfig.getInstance().fetchAndActivate().addOnCompleteListener(t->applyCfg())}
void applyCfg(){try{FirebaseRemoteConfig r=FirebaseRemoteConfig.getInstance();boolean lock=r.getBoolean("app_locked");
JSONObject o=new JSONObject().put("lock",lock).put("msg",r.getString("lock_message")).put("minv",r.getLong("min_version")).put("url",r.getString("update_url")).put("track",r.getBoolean("feature_tracking")).put("shift",r.getBoolean("feature_shift")).put("export",r.getBoolean("feature_export")).put("ann",r.getString("announcement")).put("ver",getPackageManager().getPackageInfo(getPackageName(),0).getLongVersionCode());
getSharedPreferences("a",0).edit().putString("cfgjson",o.toString()).putBoolean("lock",lock).putBoolean("noshift",!r.getBoolean("feature_shift")).apply();
if(lock||!r.getBoolean("feature_tracking"))stopService(new Intent(this,TrackService.class));
AlarmReceiver.schedule(this);runOnUiThread(()->w.evaluateJavascript("if(window.render)render()",null))}catch(Exception e){}}
@Override protected void onActivityResult(int c,int r,Intent d){if(c==9&&fc!=null){fc.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r,d));fc=null}}
@Override public void onRequestPermissionsResult(int c,String[] p,int[] g){if(c==1){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)go();else t("Konum izni gerekli")}}
@Override public void onBackPressed(){moveTaskToBack(true)}
void go(){startForegroundService(new Intent(this,TrackService.class))}
void t(String m){runOnUiThread(()->Toast.makeText(this,m,Toast.LENGTH_LONG).show())}
class Br{
@JavascriptInterface public void setAlarms(String j){getSharedPreferences("a",0).edit().putString("cfg",j).apply();AlarmReceiver.schedule(MainActivity.this)}
@JavascriptInterface public void testAlarm(String k){AlarmReceiver.fire(MainActivity.this,k)}
@JavascriptInterface public void startTrack(){runOnUiThread(()->{if(checkSelfPermission(F)==PackageManager.PERMISSION_GRANTED)go();else requestPermissions(new String[]{F},1)})}
@JavascriptInterface public String getCfg(){return getSharedPreferences("a",0).getString("cfgjson","{}")}
@JavascriptInterface public void refreshCfg(){runOnUiThread(()->fetchCfg())}
@JavascriptInterface public void openUrl(String u){runOnUiThread(()->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)))}catch(Exception e){}})}
@JavascriptInterface public void stopTrack(){stopService(new Intent(MainActivity.this,TrackService.class))}
@JavascriptInterface public boolean isTracking(){return getSharedPreferences("a",0).getBoolean("trk",false)}
@JavascriptInterface public String getAll(){JSONObject o=new JSONObject();try{for(Map.Entry<String,?> e:getSharedPreferences("a",0).getAll().entrySet())if(e.getKey().startsWith("t_")){String[] a=((String)e.getValue()).split("\\|");o.put(e.getKey().substring(2),new JSONObject().put("km",Double.parseDouble(a[0])).put("sec",Double.parseDouble(a[1])))}}catch(Exception x){}return o.toString()}
@JavascriptInterface public void saveFile(String n,String x){try{ContentValues v=new ContentValues();v.put(MediaStore.MediaColumns.DISPLAY_NAME,n);v.put(MediaStore.MediaColumns.MIME_TYPE,n.endsWith(".csv")?"text/csv":"application/json");v.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS);
Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);OutputStream o=getContentResolver().openOutputStream(u);o.write(x.getBytes("UTF-8"));o.close();t("İndirilenler klasörüne kaydedildi: "+n)}catch(Exception e){t("Kaydedilemedi")}}}}
